INSTRUCCIONES (rápido)

1) Abre la carpeta y pega tu foto con el nombre exacto:
   rafael.jpg

2) Edita tu enlace de Calendly:
   Busca: https://calendly.com/TUENLACEAQUI
   y reemplázalo por tu link real.

3) Para publicarlo:
   - Puedes subir esta carpeta a cualquier hosting (Netlify, Vercel, Hostinger, etc.)
   - El archivo principal es: index.html

LISTO ✅
